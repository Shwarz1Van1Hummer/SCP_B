
SAFE = '/media/safe_database/'
