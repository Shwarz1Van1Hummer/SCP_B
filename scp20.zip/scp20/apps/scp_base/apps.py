from django.apps import AppConfig


class ScpBaseConfig(AppConfig):
    name = 'apps.scp_base'
